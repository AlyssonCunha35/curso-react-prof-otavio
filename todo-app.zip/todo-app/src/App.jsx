import React, { useEffect, useState } from 'react';
import AddTask from './components/AddArea/AddTask';
import ListItem from './components/ListItem/ListItem';
import ShortUniqueId from 'short-unique-id';
import { Container } from './App.Styles';
import { Area } from './App.Styles';
import { Header } from './App.Styles';

const App = () => {
  const [list, setList] = useState([]);
  const [reloadTask, setReloadTask] = useState(false);
  const [task, setTask] = useState({});

  const handleAddTask = (taskName) => {
    const ids = new ShortUniqueId();
    const id = ids();
    let newList = [...list];
    newList.push({
      id: id,
      name: taskName,
      done: false,
    });
    //localStorage.setItem(TODO_STORAGE, JSON.stringify(newList));
    setList(newList);
    console.log(newList);
  };

  useEffect(() => {
    setList(list);
    setReloadTask(false);
  }, [reloadTask]);

  const handleRemoveTask = (index) => {
    list.splice(index, 1);
    setList(list);
    setReloadTask(true);
  };

  return (
    <Container>
      <Area>
        <Header>LIST OF TASKS</Header>
        <AddTask task={task} setTask={setTask} onEnter={handleAddTask} />
        {list.map((item, index) => (
          <ListItem
            key={index}
            handleRemoveTask={handleRemoveTask}
            item={item}
            task={task}
            setTask={setTask}
          />
        ))}
      </Area>
    </Container>
  );
};
export default App;
