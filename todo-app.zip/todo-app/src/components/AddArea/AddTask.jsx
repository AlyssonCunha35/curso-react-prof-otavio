import React from 'react';
import { useState } from 'react';
import { Container } from './AddStyles';
const AddTask = ({ onEnter, task, setTask }) => {
  console.log(task);

  const [inputText, setInputText] = useState('');
  const handleSubmit = (e) => {
    if (e.code === 'Enter' && inputText !== '') {
      onEnter(inputText);
      setInputText('');
    }
  };

  return (
    <Container>
      <div className="image">➕</div>
      <input
        type="text"
        placeholder="Adicionar Tarefa"
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        onKeyUp={handleSubmit}
        maxLength="50"
      />
    </Container>
  );
};

export default AddTask;
