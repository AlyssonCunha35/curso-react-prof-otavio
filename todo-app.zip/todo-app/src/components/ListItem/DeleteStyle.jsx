import styled from 'styled-components';

export const Delete = styled.div`
  svg {
    width: 30px;
    fill: #fff;
    bottom: 0;
    left: 0;
    cursor: pointer;
  }
`;
