import React from 'react';
import * as D from './DeleteStyle';
import { Container } from './ListStyle';
import { useState } from 'react';
import { Delete } from '@material-ui/icons';
import { Edit } from '@material-ui/icons';
const ListItem = ({ item, handleRemoveTask, task, setTask }) => {
  const [isChecked, setIsChecked] = useState(item.done);
  return (
    <>
      <Container done={isChecked}>
        <input
          type="checkbox"
          checked={isChecked}
          onChange={(e) => setIsChecked(e.target.checked)}
        />
        <label>{item.name}</label>

        <D.Delete>
          <Edit />
          <Delete onClick={handleRemoveTask} />
        </D.Delete>
      </Container>
    </>
  );
};
export default ListItem;
