import styled from 'styled-components';

export const Container = styled.div(
  ({ done }) =>
    `
  display: flex;
  background-color:#708090;
  padding: 10px;
  border-radius: 10px;
  margin-bottom: 10px;
  align-items: center;
  input {
    height: 25px;
    margin-right: 5px;
  }
  label {
    width:850px;
    color: #ccc;
    text-decoration:${done ? 'line-through' : 'initial'}
  }
`,
);
